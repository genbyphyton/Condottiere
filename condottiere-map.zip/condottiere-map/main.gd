extends Node2D

var regions = {
	"Scotland1": null,
	"Scotland2": null,
	"England1": null,
	"England2": null,
	"England3": null,
	"England4": null,
	"England5": null,
	"England6": null,
	"England7": null,
	"England8": null,
	"England9": null,
	"Wales1": null,
	"Wales2": null,
	"Ireland1": null,
	"Ireland2": null,
	"Ireland3": null
}

var region_values = {
	"Scotland1": 4,
	"Scotland2": 5,
	"England1": 5,
	"England2": 6,
	"England3": 7,
	"England4": 7,
	"England5": 8,
	"England6": 8,
	"England7": 7,
	"England8": 6,
	"England9": 6,
	"Wales1": 5,
	"Wales2": 4,
	"Ireland1": 3,
	"Ireland2": 4,
	"Ireland3": 3
}

var region_neighbors = {
	"Scotland1": ["Scotland2"],
	"Scotland2": ["Scotland1", "England1"],

	"England1": ["Scotland2", "England2"],
	"England2": ["England1", "England3", "England4"],
	"England3": ["England2", "England5", "Wales1"],
	"England4": ["England2", "England5"],
	"England5": ["England3", "England4", "England6", "Wales1"],
	"England6": ["England5", "England7"],
	"England7": ["England6", "England8", "Wales2"],
	"England8": ["England7", "England9"],
	"England9": ["England8"],

	"Wales1": ["England3", "England5", "Wales2"],
	"Wales2": ["Wales1", "England7"],

	"Ireland1": ["Ireland2"],
	"Ireland2": ["Ireland1", "Ireland3"],
	"Ireland3": ["Ireland2"]
}

var ai_thinking = false
var game_over = false
var win_count = 3
var total_win_count = 5

func _input(event):
	if game_over or ai_thinking:
		return

	if event is InputEventMouseButton and event.pressed:
		for region_name in regions.keys():
			check_region_click(region_name)

func check_region_click(region_name: String):
	var path = region_name + "/Polygon2D"

	if not $Map.has_node(path):
		print("Missing node: ", path)
		return

	var polygon_node = $Map.get_node(path)
	var mouse_pos = polygon_node.to_local(get_global_mouse_position())

	if Geometry2D.is_point_in_polygon(mouse_pos, polygon_node.polygon):
		if regions[region_name] == null:
			player_capture(region_name)

func player_capture(region_name: String):
	capture_region(region_name, "human")
	regions[region_name] = "human"

	if check_win("human"):
		print("Player wins!")
		game_over = true
		return

	ai_thinking = true
	await get_tree().create_timer(1.0).timeout
	ai_turn()
	ai_thinking = false

func ai_turn():
	var best_region = null
	var best_score = -999

	for region_name in regions.keys():
		if regions[region_name] != null:
			continue

		if would_win_if_captured(region_name, "ai"):
			best_region = region_name
			break

		if would_win_if_captured(region_name, "human"):
			best_region = region_name
			break

		var score = get_region_score(region_name)

		if score > best_score:
			best_score = score
			best_region = region_name

	if best_region != null:
		capture_region(best_region, "ai")
		regions[best_region] = "ai"

	if check_win("ai"):
		print("AI wins!")
		game_over = true
		return

	if is_board_full():
		print("Draw!")
		game_over = true

func get_region_score(region_name: String) -> int:
	var score = region_values[region_name]

	for neighbor in region_neighbors[region_name]:
		if regions[neighbor] == "ai":
			score += 6
		elif regions[neighbor] == "human":
			score += 4

	if is_close_to_chain(region_name, "ai"):
		score += 10

	if is_close_to_chain(region_name, "human"):
		score += 8

	if region_name.begins_with("England"):
		score += 2

	score += randi_range(0, 2)

	return score

func is_close_to_chain(region_name: String, owner: String) -> bool:
	var owned_neighbors = 0

	for neighbor in region_neighbors[region_name]:
		if regions[neighbor] == owner:
			owned_neighbors += 1

	return owned_neighbors >= 2

func would_win_if_captured(region_name: String, owner: String) -> bool:
	regions[region_name] = owner
	var result = check_win(owner)
	regions[region_name] = null
	return result

func check_win(owner: String) -> bool:
	# Условие 1: игрок захватил 5 любых регионов
	if count_total_owned(owner) >= total_win_count:
		return true

	# Условие 2: игрок захватил 3 соседних/связанных региона
	for region_name in regions.keys():
		if regions[region_name] == owner:
			var visited = {}
			var connected_count = count_connected(region_name, owner, visited)

			if connected_count >= win_count:
				return true

	return false
func count_total_owned(owner: String) -> int:
	var count = 0

	for region_name in regions.keys():
		if regions[region_name] == owner:
			count += 1

	return count

func count_connected(region_name: String, owner: String, visited: Dictionary) -> int:
	if visited.has(region_name):
		return 0

	if regions[region_name] != owner:
		return 0

	visited[region_name] = true

	var count = 1

	for neighbor in region_neighbors[region_name]:
		count += count_connected(neighbor, owner, visited)

	return count

func is_board_full() -> bool:
	for region_name in regions.keys():
		if regions[region_name] == null:
			return false

	return true

func capture_region(region_name: String, owner: String):
	var region = $Map.get_node(region_name)
	var polygon = region.get_node("Polygon2D")

	var target_color = Color(1, 1, 1, 0)

	if owner == "human":
		target_color = Color(0.2, 0.5, 1.0, 0.45)
	elif owner == "ai":
		target_color = Color(1.0, 0.2, 0.2, 0.45)

	polygon.color = Color(target_color.r, target_color.g, target_color.b, 0.0)

	var tween = create_tween()
	tween.tween_property(polygon, "color:a", 0.45, 1.2)
